package com.aplication.practica.tetris;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class ActivityJuego extends AppCompatActivity {

    private Tablero tablero;
    private Vista v;
    private VistaPiezaSiguiente vps;
    private TextView puntuacion;
    private TextView nivel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_juego);
        tablero = new Tablero();
        puntuacion = findViewById(R.id.puntuacion);
        nivel = findViewById(R.id.nivel);

        // vista de la zona de puntuacion,nivel y pieza siguiente
        RelativeLayout piezaSiguiente = (RelativeLayout) findViewById(R.id.pieza_siguiente);
        vps = new VistaPiezaSiguiente(this,tablero);
        piezaSiguiente.addView(vps);

        // vistas de la zona de juego
        RelativeLayout zonaJuego = (RelativeLayout) findViewById(R.id.zona_de_juego);
        v = new Vista(this,tablero,vps);
        v.setMain(this);
        Intent intentColores=getIntent();
        v.setLevel(nivel);
        v.setPoints(puntuacion);
        v.setColores((HashMap<String, Integer>) intentColores.getSerializableExtra("colores"));
        zonaJuego.addView(v);

    }
    public void moverDere(View view){v.moverDere();}
    public void moverIzq(View view){
        v.moverIzq();
    }
    public void caidaRapida(View view){v.caidaRapida();}

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void rotarPieza (View view){
        v.rotar();
    }
}
