package com.aplication.practica.tetris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private HashMap<String,Integer> coloresPieza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        coloresPieza = new HashMap<>();
        Intent intent = getIntent();
        coloresPieza = (HashMap<String, Integer>) intent.getSerializableExtra("hasmapRelleno");

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    // metodos para los botones

    // lanza la vista de juego
    public void jugar(View view){
        Intent intent = new Intent(this,ActivityJuego.class);
        intent.putExtra("colores",coloresPieza);
        startActivity(intent);
    }

    // lanza la personalizacion de colores para las piezas
    public void personalizaPiezas(View view){
        Intent intent = new Intent(this,personalizarPiezas.class);
        startActivity(intent);
        finish();
    }

    // lanzar la vista del ranking
    public void verRanking(View view){
        Intent intent = new Intent(this,VistaRanking.class);
        startActivity(intent);
    }
}
