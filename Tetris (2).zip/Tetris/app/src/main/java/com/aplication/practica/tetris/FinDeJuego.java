package com.aplication.practica.tetris;


import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.aplication.practica.tetris.db.AppDataBase;
import com.aplication.practica.tetris.db.Puntuacion;
import com.aplication.practica.tetris.db.PuntuacionDao;

public class FinDeJuego extends AppCompatActivity {

    private int points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_de_juego);
        Intent it = getIntent();
        points = (int) it.getSerializableExtra("points");
        final AlertDialog.Builder savePoint = new AlertDialog.Builder(this);
        savePoint.setTitle("Guardar Puntuacion");
        LayoutInflater inflater = this.getLayoutInflater();
        View myview = inflater.inflate(R.layout.guardarpuntuacion,null);
        final EditText username = myview.findViewById(R.id.username);
        final TextView puntuacion = myview.findViewById(R.id.puntuacion_user);
        puntuacion.setText(Integer.toString(points));
        savePoint.setView(myview);


        savePoint.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AppDataBase db = Room.databaseBuilder(getApplicationContext(),AppDataBase.class,"puntuacion").allowMainThreadQueries().enableMultiInstanceInvalidation().build();
                Puntuacion p = new Puntuacion(username.getText().toString(),points);
                PuntuacionDao pdao= db.puntuacionDao();
                pdao.insert(p);
                db.close();
            }
        });
        savePoint.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        savePoint.show();
    }

    public void Inicio(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void setPoints(int points) {
        this.points = points;
    }
}