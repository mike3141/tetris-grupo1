package com.aplication.practica.tetris;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.*;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Vista extends View{

    // Atributos
    private Tablero tablero;
    private VistaPiezaSiguiente vps;
    private Timer timer;
    private Timer timerpieza;
    private ActivityJuego main;
    private int tiempo;
    private Random aleatorio;
    private int puntuacion;
    private int nivel;
    private final int puntos_por_fila = 50;
    private HashMap<String,Integer> colores;
    private TextView points;
    private TextView level;
    private int cambio;
    private final int SECONDS = 30000; // esto seran nuestros 30 segundos
    private final int DESCUENTO_DE_TIEMPO = 1000; // es el valor que se restara cada vez en al tiempo
    private boolean kamikaceInicada;
    private int puesta;
    private CountDownTimer count;
    private CountDownTimer countFilas;
    private boolean unaFilaBorrada;
    private boolean dosOMasFilasBorradas;
    private int colorAleatorio;


    public Vista(Context context,Tablero tablero,VistaPiezaSiguiente vistaPiezaSiguiente){
        super(context);
        this.tablero = tablero;
        this.vps = vistaPiezaSiguiente;
        timer = new Timer();
        timerpieza = new Timer();
        tiempo = 250;
        aleatorio = new Random(System.currentTimeMillis());
        puntuacion = 0;
        nivel = 0;
        points = null;
        level = null;
        cambio = 1;


        InicioJuego();
    }

    public void setMain(com.aplication.practica.tetris.ActivityJuego main) {
        this.main = main;
    }

    public void InicioJuego(){

        // countdown de la pieza kamikace
        count = new CountDownTimer(SECONDS,DESCUENTO_DE_TIEMPO){

            @Override
            public void onTick(long millisUntilFinished) {
                System.out.println("Seconds: "+millisUntilFinished/1000);
            }

            @Override
            public void onFinish() {
                caidaRapida();
                this.start();
            }
        }.start();

        // countdown de las dos filas
        countFilas = new CountDownTimer(50000,5000){

            @Override
            public void onTick(long millisUntilFinished) {
                System.out.println("Seconds para insertar fila: "+millisUntilFinished/1000);
            }

            @Override
            public void onFinish() {
                insertarfilas();
                this.start();
            }
        }.start();

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                main.runOnUiThread(new TimerTask() {
                    @Override
                    public void run() {
                        if (!finDeJuego()){
                            tablero.gravedadPieza(tablero.getPiezaActual());
                            if (!tablero.puedeMoverse(tablero.getPiezaActual(), 1, 0)){
                                int filas_borradas = tablero.limpiarFilas();
                                tablero.limpiarFilas();
                                tablero.getListaPiezas().remove(tablero.getPiezaActual());
                                tablero.getListaPiezas().add(new Pieza(aleatorio.nextInt(7)+1));
                                vps.invalidate();
                                if(filas_borradas > 0){
                                    if(filas_borradas == 1){ // si solo se elimina una linea
                                        unaFilaBorrada = true;
                                    }
                                    if(filas_borradas > 1){ // Si se elimina mas de una linea
                                        Random red = new Random();
                                        Random green = new Random();
                                        Random blue= new Random();
                                        colorAleatorio = Color.rgb(red.nextInt(256),green.nextInt(256),blue.nextInt(256));
                                        dosOMasFilasBorradas = true;
                                    }
                                    puntuacion += filas_borradas*puntos_por_fila;
                                    points.setText("Puntuacion: "+puntuacion);
                                }

                                // funcionalidad del nivel de complejidad del juego
                                if(cambio == 1 && puntuacion >=100){
                                    nivel = 1;
                                    subirNivel(nivel);
                                    cambio++;
                                }else if(cambio == 2 && puntuacion >=200){
                                    nivel = 2;
                                    subirNivel(nivel);
                                    cambio++;
                                }else if(cambio == 3 && puntuacion >=400){
                                    nivel = 3;
                                    subirNivel(nivel);
                                    cambio++;
                                }else if(cambio == 4 && puntuacion >=600){
                                    nivel = 4;
                                    subirNivel(nivel);
                                    cambio++;
                                }else if(cambio == 5 && puntuacion >=800){
                                    nivel = 5;
                                    subirNivel(nivel);
                                    cambio++;
                                }

                            }
                            invalidate();
                        }
                    }
                });
            }
        },0,tiempo);
    }
    public void moverIzq(){

        tablero.moverIzquierda(tablero.getPiezaActual());
        invalidate();
    }
    public void moverDere(){
        tablero.moverDerecha(tablero.getPiezaActual());
        invalidate();
    }
    public void caidaRapida(){
        tablero.caidaRapida(tablero.getPiezaActual());
        invalidate();
    }
    public void rotar(){
        tablero.rotarPieza(tablero.getPiezaActual());
        invalidate();
    }
    public boolean finDeJuego(){
        if(tablero.comprobarFinDeJuego(tablero.getPiezaActual()) && tablero.comprobarFinDeJuego(tablero.getPiezaSiguiente())){
            timer.cancel();
            count.cancel();
            countFilas.cancel();
            tablero.getListaPiezas().clear();
            // limpiamos el tablero
            for (int i = 0;i<tablero.getALTO();i++){
                for (int j = 0; j < tablero.getANCHO();j++){
                    tablero.getM_tablero()[i][j] = 0;
                }
            }
            main.onPause();
            Intent intent = new Intent(this.main,FinDeJuego.class);
            intent.putExtra("points",puntuacion);
            this.main.startActivity(intent);
            //this.main.finish();
            return true;
        }
        return false;
    }
    private void subirNivel(int nivel){
        level.setText("Nivel: "+nivel);
        tiempo -= nivel*15;
        timer.cancel();
        timer = new Timer();
        InicioJuego();

    }

    /*
     * piezas que tendra nuestro juego
     * 1 cuadrado
     * 2 Z
     * 3 I
     * 4 T
     * 5 S
     * 6 J
     * 7 L
     * */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint p = new Paint();
        if (colores != null){
            for (int i = 0;i<tablero.getALTO();i++){
                for (int j = 0;j< tablero.getANCHO();j++){
                    switch(tablero.getM_tablero()[i][j]){
                        case 0:
                            p.setColor(Color.BLACK);
                            break;
                        case 1:
                            p.setColor(colores.get("Cuadrado"));
                            break;
                        case 2:
                            p.setColor(colores.get("Pieza Z"));
                            break;
                        case 3:
                            p.setColor(colores.get("Pieza I"));
                            break;
                        case 4:
                            p.setColor(colores.get("Pieza T"));
                            break;
                        case 5:
                            p.setColor(colores.get("Pieza S"));
                            break;
                        case 6:
                            p.setColor(colores.get("Pieza J"));
                            break;
                        case 7:
                            p.setColor(colores.get("Pieza L"));
                            break;
                        case 9:
                            p.setColor(Color.parseColor("#6C6C88"));
                            break;
                    }
                    canvas.drawRect(j*60,i*60,j*60+60,i*60+60,p);
                }
            }
        }else{
            for (int i = 0;i<tablero.getALTO();i++){
                for (int j = 0;j< tablero.getANCHO();j++){
                    switch(tablero.getM_tablero()[i][j]){
                        case 0:
                            p.setColor(Color.BLACK);
                            break;
                        case 1:
                            p.setColor(Color.YELLOW);
                            break;
                        case 2:
                            p.setColor(Color.RED);
                            break;
                        case 3:
                            p.setColor(Color.CYAN);
                            break;
                        case 4:
                            p.setColor(Color.parseColor("#800080"));
                            break;
                        case 5:
                            p.setColor(Color.GREEN);
                            break;
                        case 6:
                            p.setColor(Color.BLUE);
                            break;
                        case 7:
                            p.setColor(Color.parseColor("#ff8000"));
                            break;
                        case 9:
                            p.setColor(Color.parseColor("#6C6C88"));
                            break;
                    }
                    canvas.drawRect(j*60,i*60,j*60+60,i*60+60,p);
                }
            }
        }
        if(unaFilaBorrada) { // Si se elimina una linea
            dosOMasFilasBorradas = false;
            System.out.println("EL NUMERO DE CANVAS ES : " + canvas.getSaveCount());
            for (int i = 0; i < tablero.getALTO(); i++) {
                for (int j = 0; j < tablero.getANCHO(); j++) {
                    switch (tablero.getM_tablero()[i][j]) {
                        case 0:
                            p.setColor(Color.BLACK);
                            break;
                        default:
                            p.setColor(Color.parseColor("#21610B"));
                            break;
                        case 9:
                            p.setColor(Color.parseColor("#6C6C88"));
                            break;
                    }
                    canvas.drawRect(j * 60, i * 60, j * 60 + 60, i * 60 + 60, p);
                }
            }
        }
        if(dosOMasFilasBorradas) { // Si se elimina mas de una linea
            unaFilaBorrada = false;
            System.out.println("EL NUMERO DE CANVAS ES : " + canvas.getSaveCount());
            for (int i = 0; i < tablero.getALTO(); i++) {
                for (int j = 0; j < tablero.getANCHO(); j++) {
                    switch (tablero.getM_tablero()[i][j]) {
                        case 0:
                            p.setColor(Color.BLACK);
                            break;
                        case 1:
                            p.setColor(colorAleatorio);
                            break;
                        case 2:
                            p.setColor(colorAleatorio);
                            break;
                        case 3:
                            p.setColor(colorAleatorio);
                            break;
                        case 4:
                            p.setColor(colorAleatorio);
                            break;
                        case 5:
                            p.setColor(colorAleatorio);
                            break;
                        case 6:
                            p.setColor(colorAleatorio);
                            break;
                        case 7:
                            p.setColor(colorAleatorio);
                            break;
                        case 8:
                            p.setColor(colorAleatorio);
                            break;
                        case 9:
                            p.setColor(Color.parseColor("#6C6C88"));
                            break;
                    }
                    canvas.drawRect(j * 60, i * 60, j * 60 + 60, i * 60 + 60, p);
                }
            }
        }
    }

    public void setColores(HashMap<String, Integer> colores) {
        this.colores = colores;
    }

    public void setPoints(TextView points) {
        this.points = points;
    }

    public void setLevel(TextView level) {
        this.level = level;
    }

    public void insertarfilas(){
        tablero.borrarPieza(tablero.getPiezaActual()); // borrado de pieza
        for (int i = 2; i < tablero.getALTO();i++){
            for (int j = 0; j < tablero.getANCHO();j++){
                if(i!=34){
                    tablero.getM_tablero()[i-2][j] = tablero.getM_tablero()[i][j];
                    tablero.getM_tablero()[i-1][j] = tablero.getM_tablero()[i+1][j];
                }else{
                    tablero.getM_tablero()[i-2][j] = tablero.getM_tablero()[i][j];
                    tablero.getM_tablero()[i][j] = 9;
                    tablero.getM_tablero()[i-1][j] = 9;
                }
            }
        }
        tablero.ponerPieza(tablero.getPiezaActual());
        invalidate();
    }

}
